// script.js

document.getElementById("start-button").addEventListener("click", () => {
  if (!azureConfig || !azureConfig.subscriptionKey || !azureConfig.region) {
    alert("Azure Speech credentials missing in speech-config.js");
    return;
  }

  const speechConfig = SpeechSDK.SpeechConfig.fromSubscription(
    azureConfig.subscriptionKey,
    azureConfig.region
  );
  speechConfig.speechRecognitionLanguage = "en-US";

  const audioConfig = SpeechSDK.AudioConfig.fromDefaultMicrophoneInput();
  const recognizer = new SpeechSDK.SpeechRecognizer(speechConfig, audioConfig);

  document.getElementById("status").innerText = "🎤 Listening...";

  recognizer.recognizeOnceAsync(result => {
    const command = result.text.toLowerCase().replace(/\./g, "").trim();
    document.getElementById("status").innerText = `✅ Heard: "${command}"`;
    handleCommand(command);
    recognizer.close();
  });
});

function handleCommand(command) {
  if (command.includes("scroll down")) {
    window.scrollBy({ top: 300, behavior: "smooth" });
  } else if (command.includes("click menu")) {
    document.getElementById("menu")?.click();
  } else if (command.includes("go to contact")) {
    document.getElementById("contact")?.scrollIntoView({ behavior: "smooth" });
  } else if (command.startsWith("search for")) {
    const term = command.replace("search for", "").trim();
    document.getElementById("search").value = term;
  } else {
    document.getElementById("status").innerText = "⚠️ Command not recognized.";
  }
}
